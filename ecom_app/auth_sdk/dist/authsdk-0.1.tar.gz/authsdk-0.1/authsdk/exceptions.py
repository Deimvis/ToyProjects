
class BadCredentials(Exception):
    pass
